package org.example.javaed_sportclub.repository;

import org.example.javaed_sportclub.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelRepository extends JpaRepository<Hotel, Long> {
}
